package cnfcomponents;
/**
 *
 * @author MAZ
 */
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.LinkedList;

public final class CNFBooleanFormula {

  private final List<DisjunctiveBooleanClause> clauses;
  private final Map<Integer, BooleanVariable> variables;
  private int nextIndex;

  /**
   *
   **/
  public CNFBooleanFormula () {
    clauses   = new LinkedList<>();
    variables = new LinkedHashMap<>();
    nextIndex = 1;
  }

  public void addClause (final DisjunctiveBooleanClause x) {
    clauses.add(x);
  }

  public BooleanVariable newVariable (final String label) {
    final BooleanVariable v = new BooleanVariable(nextIndex, label);
    variables.put(nextIndex, v);
    ++nextIndex;
    return v;
  }

  public BooleanVariable newVariable () {
    return newVariable("");
  }

  public BooleanVariable getVariable (final int index) {
    return variables.get(index);
  }

  public boolean variableExists (final int index) {
    return variables.containsKey(index);
  }

  //
  // Escribe la codificación en formato DIMACS de la fórmula sobre el stream
  //
  public void print (final OutputStream os) throws IOException {

    try (final PrintWriter dos = new PrintWriter(new BufferedWriter(new OutputStreamWriter(os)))) {

      final String declaration = "p cnf " + variables.size() + " " + clauses.size();
      dos.println(declaration);

      clauses.forEach((clause) -> {
        dos.println(clause.print());
      });

    }

  }

  //
  // Escribe la codificación en formato DIMACS de la fórmula sobre el stream
  //
  public void printWithLabels (final OutputStream os) throws IOException {

    try (final PrintWriter dos = new PrintWriter(new BufferedWriter(new OutputStreamWriter(os)))) {

      final String declaration = "p cnf " + variables.size() + " " + clauses.size();
      dos.println(declaration);

      clauses.forEach((clause) -> {
        dos.println(clause.printWithLabels());
      });

    }

  }

}