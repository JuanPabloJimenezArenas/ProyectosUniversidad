package nqueens;
/**
 *
 * @author MAZ
 */
import cnfcomponents.CNFBooleanFormula;
import cnfcomponents.BooleanVariable;
import cnfcomponents.BooleanLiteral;
//
final class VariableMatrix {
 
  final BooleanVariable[][] pool;
  final int nrows;
  final int ncols;
  
  public VariableMatrix (final int rows, final int cols, final CNFBooleanFormula phi) {
      
    this.nrows = rows;
    this.ncols = cols;
    pool = new BooleanVariable[nrows][ncols];
    
    int index = 0;
    for (int xr = 0; xr < nrows; ++xr)
      for (int xc = 0; xc < ncols; ++xc) {
        
        ++index;
        final String name = Integer.toString(index);
        pool[xr][xc] = phi.newVariable(name);
        
      }
                
  }
  
  public BooleanVariable getVariable (final int k, final int j) {
    return pool[k - 1][j - 1];
  }  
  
  public BooleanLiteral getPositiveLiteral (final int k, final int j) {
    return pool[k - 1][j - 1].getPositiveLiteral();
  }
  
  public BooleanLiteral getNegativeLiteral (final int k, final int j) {
    return pool[k - 1][j - 1].getNegativeLiteral();
  }  
    
}