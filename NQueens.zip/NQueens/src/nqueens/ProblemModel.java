package nqueens;
/**
 *
 * @author MAZ
 */
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
//
import static java.lang.Integer.max;
import cnfcomponents.BooleanLiteral;
import cnfcomponents.BooleanVariable;
import cnfcomponents.CNFBooleanFormula;
import cnfcomponents.DisjunctiveBooleanClause;
//
public final class ProblemModel {
  
  private final VariableMatrix tablero;
  private final CNFBooleanFormula phi;
  private final int n;
  
  public ProblemModel (final int n) {
    this.n = n;
    phi = new CNFBooleanFormula();
    tablero = new VariableMatrix(n, n, phi);
  }
  
  public CNFBooleanFormula encoding () {
    
    final List<BooleanLiteral> literals = new ArrayList<>();
    
    // Al menos una reina por fila
    for (int i = 1; i <= n; ++i) {
      
      for (int j = 1; j <= n; ++j) {
        
            literals.add(tablero.getPositiveLiteral(i, j));
      }
      phi.addClause(new DisjunctiveBooleanClause(literals));      
      literals.clear();
    }
    

    // A lo sumo una reina por fila
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <n; ++j) {
            for (int k = j+1; k <= n; ++k){
                phi.addClause(new DisjunctiveBooleanClause(tablero.getNegativeLiteral(i, j),tablero.getNegativeLiteral(i, k)));      
            }
        }
 
    }
      
    
    // Al menos una reina por columna
    for (int i = 1; i <= n; ++i) {
      for (int j = 1; j <= n; ++j) {
            literals.add(tablero.getPositiveLiteral(j, i));
      }
      phi.addClause(new DisjunctiveBooleanClause(literals));      
      literals.clear();
    }
    
    // A lo sumo una reina por columna
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j < n; ++j) {
            for (int k = j; k <= n; ++k){
            phi.addClause(new DisjunctiveBooleanClause(tablero.getNegativeLiteral(j, i),tablero.getNegativeLiteral(k, i)));      
            }
        }
 
    }
    
    //
    // A lo sumo una reina por diagonal \
    //
    for (int d = 1 - n; d < n; ++d) { // d es índice de diagonal
        int inicio = 0 > -d ? 0 : -d;
        int finalInt = 0 > d ? 0 : d;
        for (int i = inicio+1; i<n-finalInt; i++){
            for (int k=i+1; k<=n-finalInt; k++){
                phi.addClause(new DisjunctiveBooleanClause(tablero.getNegativeLiteral(i, i+d),tablero.getNegativeLiteral(k, k+d)));      
            }
        }
        
    }

    //
    // A lo sumo una reina por contradiagonal /
    //
    for (int d = 1 - n; d < n; ++d) { // d es índice de contradiagonal
        int inicio = 0 > -d ? 0 : -d;
        int finalInt = 0 > d ? 0 : d;
        for (int i = inicio+1; i<n-finalInt; i++){
            for (int k=i+1; k<=n-finalInt; k++){
                phi.addClause(new DisjunctiveBooleanClause(tablero.getNegativeLiteral(i, n+1-(i+d)),tablero.getNegativeLiteral(k, n+1-(k+d))));      
            }
        }
    }    

    return phi;
    
  }
  
  public void synthesis (final InputStream input) throws IOException {
    
    try (final Scanner scanner = new Scanner(input)) {
   
      final String resolutionResult = scanner.nextLine();
      if (resolutionResult.compareTo("s SATISFIABLE") == 0) {

        while (scanner.hasNextLine()) {

          final String initialToken = scanner.next();
          if (initialToken.compareTo("v") == 0) {
            while (scanner.hasNextInt()) {
              final int index = scanner.nextInt();
              final boolean isPositive = index > 0;
              if (phi.variableExists(isPositive ? index : -index)) {
                final BooleanVariable x = phi.getVariable(isPositive ? index : -index);
                x.setValue(isPositive);
              }
            }
          }
          scanner.nextLine();
        }

        printSolution();

      }
    
    }
    
  }
  
  private void printSolution () {
    for (int i = 1; i <= n; ++i) {
      for (int j = 1; j <= n; ++j) {
        if (tablero.getVariable(i, j).getValue()) {
          System.out.print("X ");
        } else {
          System.out.print(". ");
        }
      }
      System.out.println();
    }
  }
  
}