package main;
/**
 *
 * @author MAZ
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Path;
//
import nqueens.ProblemModel;

public class SolutionSynthesis {
  
  public static void main (final String[] args) {
 
    if (args.length != 2) {
      System.err.println("Uso: <n:int> <filename.res>");
      return;
    }
    
    final int n = Integer.valueOf(args[0]);
    final String inputFileName  = args[1];
    
    final FileSystem fileSystem = FileSystems.getDefault();
    final Path path = fileSystem.getPath("data", inputFileName); 
    final File inFile = path.toFile();   
    final ProblemModel synthesizer = new ProblemModel(n);

    try {
      synthesizer.synthesis(new FileInputStream(inFile));
    } catch (final FileNotFoundException ex) {
      System.err.printf("Fichero %s no encontrado\n", inFile.getName());
    } catch (final IOException ex) {
      System.err.printf("Prblema de I/O al procesar fichero %s\n", inFile.getName());
    }  

  }
    
}