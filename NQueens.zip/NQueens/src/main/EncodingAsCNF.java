package main;
/**
 *
 * @author MAZ
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
//
import cnfcomponents.CNFBooleanFormula;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import nqueens.ProblemModel;
//
public class EncodingAsCNF {
    
  public static void main (final String[] args) {
 
    if (args.length != 2) {
      System.err.println("Uso: <n:int> <filename.cnf>");
      return;
    }
    
    final int n = Integer.valueOf(args[0]);
    final String outputFileName = args[1];    
    
    final ProblemModel synthesizer = new ProblemModel(n);
    final CNFBooleanFormula phi = synthesizer.encoding();
    
    final FileSystem fileSystem = FileSystems.getDefault();
    final Path path = fileSystem.getPath("data", outputFileName);
    final File outFile = path.toFile();

    try {
      phi.print(new FileOutputStream(outFile));
    } catch (final FileNotFoundException ex) {
      System.err.printf("Fichero %s no encontrado\n", outFile.getName());
    } catch (final IOException ex) {
      System.err.printf("Prblema de I/O al procesar fichero %s\n", outFile.getName());
    }
    
  }
    
}