package oso.ui;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author juanp
 */
public class Tablero {
    char tablero[][];
    int tableroAux[][]; //0 libre, 1 aliados, 2 enemigos, 3 en uso
    int x,y,osos,ososA,ososE;
    String nombre;
    public Tablero(int x, int y){
        this.x=x;
        this.y=y;
        this.osos = 0;
        this.tablero = new char[this.x][this.y];
        this.tableroAux = new int[this.x][this.y];
        
        for(int i=0;i<x;i++){
            for(int j=0;j<y;j++){
                this.tablero[i][j] = ' ';
                this.tableroAux[i][j] = 0;
            }
        }
    }
    
    public Tablero(int x, int y, String nombre){
        this.nombre = nombre;
        this.x=x;
        this.y=y;
        this.osos = 0;
        this.ososA = 0;
        this.ososE = 0;
        this.tablero = new char[this.x][this.y];
        this.tableroAux = new int[this.x][this.y];
        for(int i=0;i<x;i++){
            for(int j=0;j<y;j++){
                this.tablero[i][j] = ' ';
                this.tableroAux[i][j] = 0;
            }
        }
    }
    
    public boolean ponerPieza(int x, int y, char pieza){
        pieza = Character.toUpperCase(pieza);
        if((pieza == 'S' || pieza == 'O') && (x>=0 && x<this.x) && (y>=0 && y<this.y)){ 
            if(this.tablero[x][y] == ' '){
                this.tablero[x][y] = pieza;
                this.tableroAux[x][y] = 3;
                return true;
            }
        }
        return false;
    }
    
    public boolean tableroLleno(){
        for(int i=0;i<this.x;i++){
            for(int j=0;j<this.y;j++){
                if(this.tablero[i][j] == ' ')
                    return false;
            }           
        }
        return true;
    }
    
    public void comprobarOso(){
        String oso;
        boolean libre;
        for(int i=0;i<this.x;i++){
            for(int j=0;j<this.y;j++){
                if(this.tablero[i][j] == 'S'){
                    if(i!=0 && i!=this.x-1 && j!=0 && j!=this.y-1){
                        oso = "" + this.tablero[i-1][j-1]+this.tablero[i][j]+this.tablero[i+1][j+1];
                        libre = (this.tableroAux[i-1][j-1] != 1 && this.tableroAux[i][j] != 1 && this.tableroAux[i+1][j+1] != 1);
                        if(oso.equals("OSO") && libre){
                            this.tableroAux[i-1][j-1] = 1;
                            this.tableroAux[i][j] = 1;
                            this.tableroAux[i+1][j+1] = 1;
                            this.osos++;
                            return;
                        }
                        oso = "" + this.tablero[i-1][j+1]+this.tablero[i][j]+this.tablero[i+1][j-1];
                        libre = (this.tableroAux[i-1][j+1] != 1 && this.tableroAux[i][j] != 1 && this.tableroAux[i+1][j-1] != 1);
                        if(oso.equals("OSO") && libre){
                            this.tableroAux[i-1][j+1] = 1;
                            this.tableroAux[i][j] = 1;
                            this.tableroAux[i+1][j-1] = 1;
                            this.osos++;
                            return;
                        }
                    }
                    if(i!=0 && i!=this.x-1){
                        oso = ""+this.tablero[i-1][j]+this.tablero[i][j]+this.tablero[i+1][j];
                        libre = (this.tableroAux[i-1][j] != 1 && this.tableroAux[i][j] != 1 && this.tableroAux[i+1][j] != 1);
                        if(oso.equals("OSO") && libre){
                            this.tableroAux[i-1][j] = 1;
                            this.tableroAux[i][j] = 1;
                            this.tableroAux[i+1][j] = 1;
                            this.osos++;
                            return;
                        }
                    }
                    if(j!=0 && j!=this.y-1){
                        oso = ""+this.tablero[i][j-1]+this.tablero[i][j]+this.tablero[i][j+1];
                        libre = (this.tableroAux[i][j-1] != 1 && this.tableroAux[i][j] != 1 && this.tableroAux[i][j+1] != 1);
                        if(oso.equals("OSO") && libre){
                            this.tableroAux[i][j-1] = 1;
                            this.tableroAux[i][j] = 1;
                            this.tableroAux[i][j+1] = 1;
                            this.osos++;
                            return;
                        }
                    }
                }
            }
        }
    }
    
    public void comprobarOso(String nombre){
        String oso;
        boolean noLibre;
        int aux = (nombre.equals(this.nombre)) ? 1: 2;
        for(int i=0;i<this.x;i++){
            for(int j=0;j<this.y;j++){
                if(this.tablero[i][j] == 'S'){
                    if(i!=0 && i!=this.x-1 && j!=0 && j!=this.y-1){
                        oso = "" + this.tablero[i-1][j-1]+this.tablero[i][j]+this.tablero[i+1][j+1];
                        noLibre = (this.tableroAux[i-1][j-1] == 3 && this.tableroAux[i][j] == 3 && this.tableroAux[i+1][j+1] == 3);
                        if(oso.equals("OSO") && noLibre){
                            this.tableroAux[i-1][j-1] = aux;
                            this.tableroAux[i][j] = aux;
                            this.tableroAux[i+1][j+1] = aux;
                            this.contarOso(aux);
                            return;
                        }
                        oso = "" + this.tablero[i-1][j+1]+this.tablero[i][j]+this.tablero[i+1][j-1];
                        noLibre = (this.tableroAux[i-1][j+1] == 3 && this.tableroAux[i][j] == 3 && this.tableroAux[i+1][j-1] == 3);
                        if(oso.equals("OSO") && noLibre){
                            this.tableroAux[i-1][j+1] = aux;
                            this.tableroAux[i][j] = aux;
                            this.tableroAux[i+1][j-1] = aux;
                            this.contarOso(aux);
                            return;
                        }
                    }
                    if(i!=0 && i!=this.x-1){
                        oso = ""+this.tablero[i-1][j]+this.tablero[i][j]+this.tablero[i+1][j];
                        noLibre = (this.tableroAux[i-1][j] == 3 && this.tableroAux[i][j] == 3 && this.tableroAux[i+1][j] == 3);
                        if(oso.equals("OSO") && noLibre){
                            this.tableroAux[i-1][j] = aux;
                            this.tableroAux[i][j] = aux;
                            this.tableroAux[i+1][j] = aux;
                            this.contarOso(aux);
                            return;
                        }
                    }
                    if(j!=0 && j!=this.y-1){
                        oso = ""+this.tablero[i][j-1]+this.tablero[i][j]+this.tablero[i][j+1];
                        noLibre = (this.tableroAux[i][j-1] == 3 && this.tableroAux[i][j] == 3 && this.tableroAux[i][j+1] == 3);
                        if(oso.equals("OSO") && noLibre){
                            this.tableroAux[i][j-1] = aux;
                            this.tableroAux[i][j] = aux;
                            this.tableroAux[i][j+1] = aux;
                            this.contarOso(aux);
                            return;
                        }
                    }                   
                }
            }
        }
    }
    
    public Tablero clonar(){
        Tablero clon = new Tablero(x,y,nombre);
        for(int i=0;i<this.x;i++){
            for(int j=0;j<this.y;j++){
                clon.tablero[i][j] = this.tablero[i][j];
                clon.tableroAux[i][j] = this.tableroAux[i][j];
            }
        }
        clon.setOsosA(this.ososA);
        clon.setOsosE(this.ososE);
        return clon;
    }
    
    private void contarOso(int i){
        if(i==2){
            this.ososE++;
        }
        else{
            this.ososA++;
        }
    }

    public int getOsos() {
        return osos;
    }
    
    public char getPieza(int x, int y){
        return tablero[x][y];
    }

    public int getOsosA() {
        return ososA;
    }

    public int getOsosE() {
        return ososE;
    }    
    public int getIntAux(int x, int y) {
        return this.tableroAux[x][y];
    }
    
    public String getDim(){
        return ""+this.x+","+this.y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    
    public boolean esGanador(){
        return this.ososA > this.ososE;
    }

    public void setOsosA(int ososA) {
        this.ososA = ososA;
    }

    public void setOsosE(int ososE) {
        this.ososE = ososE;
    }

    @Override
    public String toString() {
        String texto;
        texto = "-----TABLERO-----\n";
        for(char i[]:this.tablero){
            for(char j:i){
                texto += j+",";
            }
            texto += "\n";
        }
        texto += "-----------------\n";
        String texto2;
        texto2 = "-----TABLEROAUX-----\n";
        for(int i[]:this.tableroAux){
            for(int j:i){
                texto2 += j+",";
            }
            texto2 += "\n";
        }
        texto2 += "-----------------\n";
        return texto+texto2;
    }
    /*public String toString() {
        String texto;
        texto = "-----TABLERO-----\n";
        for(char i[]:this.tablero){
            for(char j:i){
                texto += j+",";
            }
            texto += "\n";
        }
        texto += "-----------------\n";
        return texto;
    }*/

    public void resetear() {
        for(int i=0;i<this.x;i++){
            for(int j=0;j<this.y;j++){
                this.tablero[i][j] = ' ';
                this.tableroAux[i][j] = 0;
            }
        }
        this.ososA = 0;
        this.ososE = 0;
    }
}
