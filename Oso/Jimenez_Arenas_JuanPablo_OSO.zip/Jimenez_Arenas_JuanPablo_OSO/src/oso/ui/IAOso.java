/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oso.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author juanp
 */
public class IAOso {
    //-------------------TADS-------------------------------
    public class MinimaxResult {
        public int valor;
        public int[] mejorMovimiento;

        public MinimaxResult(int valor, int[] mejorMovimiento) {
            this.valor = valor;
            this.mejorMovimiento = mejorMovimiento;
        }
    }
    
    private class MovimientoAplicado{
        private Tablero tablero;
        private boolean repiteTurno;

        public MovimientoAplicado(Tablero tablero, boolean repiteTurno) {
            this.tablero = tablero;
            this.repiteTurno = repiteTurno;
        } 
    }
    //-------------------------------------------------------
    private String nombreIA,nombreJ;
    private boolean tableroPropio;
    public IAOso(String nombre, boolean tableroPropio) {
        this.nombreIA = nombre+"IA";
        this.nombreJ = nombre;
        this.tableroPropio = tableroPropio;
    }
    
    private MovimientoAplicado aplica(Tablero tableroAnt, int[] posible, String jugador) {
        Tablero tableroAux = tableroAnt.clonar();
        int x = posible[0];
        int y = posible[1];
        char p = (posible[2] == 1) ? 'S':'O';
        int ososAnt = (jugador.equals(this.nombreIA)) ? tableroAnt.getOsosE():tableroAnt.getOsosA();
        tableroAux.ponerPieza(x, y, p);
        tableroAux.comprobarOso(jugador);
        int osoDes = (jugador.equals(this.nombreIA)) ? tableroAnt.getOsosE():tableroAnt.getOsosA();
        boolean repite = (ososAnt < osoDes);
        return new MovimientoAplicado(tableroAux,repite);
    }
    
    public MinimaxResult calcularMovimientoMinMax(Tablero tableroAnt, int alpha, int beta, String jugadorMAX, int profundidad){
        if (profundidad == 0 || tableroAnt.tableroLleno()) {
            int val = eval(tableroAnt);
            return new MinimaxResult(val,null);
        }
        List<int[]> movimientosOrdenados = calcularMovimientos(tableroAnt);
        String siguienteAux = (this.nombreIA.equals(jugadorMAX)) ? this.nombreJ : this.nombreIA;
        int[] mejorMov = null;

        if (jugadorMAX.equals(this.nombreIA)) {
            int value = -999;
            for (int[] posible : movimientosOrdenados) {
                MovimientoAplicado nuevoMov = aplica(tableroAnt, posible, jugadorMAX);
                String siguiente = (nuevoMov.repiteTurno) ? jugadorMAX : siguienteAux;
                MinimaxResult resultado = calcularMovimientoMinMax(nuevoMov.tablero, alpha, beta, siguiente, profundidad - 1);
                if (resultado.valor > value) {
                    value = resultado.valor;
                    mejorMov = posible;
                    alpha = value;
                }
                if (alpha >= beta) break;
            }
            return new MinimaxResult(value, mejorMov);
        } else {
            int value = 999;
            for (int[] posible : movimientosOrdenados) {
                MovimientoAplicado nuevoMov = aplica(tableroAnt, posible, jugadorMAX);
                String siguiente = (nuevoMov.repiteTurno) ? jugadorMAX : siguienteAux;
                MinimaxResult resultado = calcularMovimientoMinMax(nuevoMov.tablero, alpha, beta, siguiente, profundidad-1);
                if (resultado.valor < value) {
                    value = resultado.valor;
                    mejorMov = posible;
                    beta = value;
                }
                if (alpha >= beta) break;
            }
            return new MinimaxResult(value, mejorMov);
        }
    }
    //------------------------------------LO UNICO QUE SE USA PARA HACER LOS MOVIMIENTOS ALEATORIOS-----------------------------------------------
    private ArrayList<int[]> calcularMovimientos(Tablero tableroAux){
        List<int[]> lista = new ArrayList<int[]>();
        int x = tableroAux.getX();
        int y = tableroAux.getY();
        for(int i=0;i<x;i++){
            for(int j=0;j<y;j++){
                if(tableroAux.getIntAux(i,j) == 0){
                    int[] aux = {i,j,0};
                    lista.add(aux);
                    int[] aux2 = {i,j,1};
                    lista.add(aux2);
                }
            }
        }
        Random rand = new Random();
        for (int i = 0; i < lista.size(); i++) {
            int index = (int)(rand.nextInt(lista.size()));
            int[] temp = lista.get(i);
            lista.set(i, lista.get(index));
            lista.set(index, temp);
        }
        return (ArrayList<int[]>) lista;
    }
    public int[] movAleatorio(Tablero tablero){
        ArrayList<int[]> lista = this.calcularMovimientos(tablero);
        Random r = new Random();
        int index = (int) (r.nextInt(lista.size()));
        return lista.get(index);
    }
    //------------------------------------LO UNICO QUE SE USA PARA HACER LOS MOVIMIENTOS ALEATORIOS-----------------------------------------------
    public boolean otraVez(int osoAnt, Tablero tablero){
        int osoAux = (this.tableroPropio) ? tablero.getOsosA() : tablero.getOsosE();
        return osoAnt < osoAux;
    }
    
    private int eval(Tablero tableroAnt) {
        return (this.tableroPropio) ? tableroAnt.getOsosA()-tableroAnt.getOsosE() : tableroAnt.getOsosE()-tableroAnt.getOsosA();
    }
}
