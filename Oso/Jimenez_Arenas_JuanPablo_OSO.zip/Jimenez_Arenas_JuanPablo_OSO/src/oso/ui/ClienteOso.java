/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oso.ui;

import java.awt.Component;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author juanp
 */
public class ClienteOso extends Thread{

    private String nombre,ip,nombreOriginal;
    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;
    private Tablero tablero;
    private JPanel jPanelTablero;
    private JTextField jTextFieldOsoA,jTextFieldOsoE;
    private int turno,puerto;
    
    
    public ClienteOso(String nombre, String add, int port, Tablero tablero, JPanel jPanelTablero, JTextField jTextFieldOsoA, JTextField jTextFieldOsoE) throws IOException {
        this.jPanelTablero = jPanelTablero;
        this.tablero = tablero;
        this.nombre = nombre;
        this.nombreOriginal = nombre;
        this.jTextFieldOsoA =jTextFieldOsoA;
        this.jTextFieldOsoE = jTextFieldOsoE;
        this.puerto = port;
        this.ip = add;
        socket = new Socket(add, port);
        in = new DataInputStream(
               socket.getInputStream());
        out = new DataOutputStream(
               socket.getOutputStream());
        this.turno = 0;
    }

    public void envioMsg(String msg,boolean otra) throws IOException{
        String mensage = (otra) ? this.nombre+":"+msg+":"+1 : this.nombre+":"+msg+":"+0;
        out.writeUTF(mensage);
    }

    public String recMsg() throws IOException{
        return in.readUTF();
    }
    
    private void actualizarTablero(int x, int y, char pieza, String nombre, boolean otra) throws IOException{
        tablero.ponerPieza(x,y,pieza);
        tablero.comprobarOso(nombre);
        Component[] botones = jPanelTablero.getComponents();
        for(Component boton:botones){
            ((JButtonOso) boton).actualizarBoton();
            if(!otra){
                ((JButtonOso) boton).reactivarBoton();
            }
        }
        jPanelTablero.revalidate();
        jTextFieldOsoA.setText(""+this.tablero.getOsosA());
        jTextFieldOsoE.setText(""+this.tablero.getOsosE());
        if(this.tablero.tableroLleno()){
            boolean win;
            if(this.tablero.getOsosA()>this.tablero.getOsosE()){
                JOptionPane.showMessageDialog(null,"Has ganado!!!","Fin de partida",JOptionPane.INFORMATION_MESSAGE);
                win = true;
            }else if(this.tablero.getOsosA()<this.tablero.getOsosE()){
                JOptionPane.showMessageDialog(null,"Has predido :(","Fin de partida",JOptionPane.INFORMATION_MESSAGE);
                win = false;
            }else{
                JOptionPane.showMessageDialog(null,"Empate","Fin de partida",JOptionPane.INFORMATION_MESSAGE);
                win = false;
            }
            String msg = "FIN:"+this.tablero.getOsosA();
            this.envioMsg(msg,win);
        }
    }
    
    private void resetearTablero(){
        this.tablero.resetear();
        Component[] botones = jPanelTablero.getComponents();
        for(Component boton:botones){
            ((JButtonOso) boton).actualizarBoton();
            ((JButtonOso) boton).reactivarBoton();
            if(this.turno == 2 || this.turno == 0){
                ((JButtonOso) boton).setEnabled(false);
            }else{
                ((JButtonOso) boton).setEnabled(true);
            }
            
        }
        jTextFieldOsoA.setText(""+this.tablero.getOsosA());
        jTextFieldOsoE.setText(""+this.tablero.getOsosE());
        jPanelTablero.revalidate();
    }
    
    public void desconectar(){
        try {
            socket.close();
        } catch (Exception ex) {}
    }
    
    private void iniciar(){
        Component[] botones = jPanelTablero.getComponents();
        for(Component boton: botones){
            if(this.turno == 2){
                ((JButtonOso) boton).setEnabled(false);
            }else{
                ((JButtonOso) boton).setEnabled(true);
            }
        }
    }
    private void reencolar() throws IOException{
        this.nombre = this.nombreOriginal;
        this.resetearTablero(); 
        try {
            socket.close();
        } catch (IOException ex) {}
        socket = new Socket(this.ip, this.puerto);
        in = new DataInputStream(
               socket.getInputStream());
        out = new DataOutputStream(
               socket.getOutputStream());
        this.turno = 0;
        this.resetearTablero();
        String mensaje = "Inicial:"+this.nombre;
        try {
            out.writeUTF(mensaje);
        } catch (IOException ex) {}
    }
    @Override
    public synchronized void run() {
        try {
            String mensage = "Inicial:"+this.nombre;
            out.writeUTF(mensage);
            for(String linea; (linea = recMsg())!=null;){
                System.out.println("Mensaje:"+linea);
                if(linea.equals("INCIO_DATOS")){
                    cargarTxt();
                }else if(linea.startsWith("Turno:")){
                    String[] datos = linea.split(":");
                    this.turno = Integer.parseInt(datos[1]);
                    this.nombre = datos[2];
                    this.iniciar();
                }else if(linea.endsWith("EXIT")){
                    this.reencolar();
                }else{
                    String[] datos = linea.split(":");
                    String nombreAux = datos[0];
                    if(datos[1].equals("RESET")){
                        this.resetearTablero();
                    }else{
                        boolean otra = datos[2].equals("1");
                        String[] cord = datos[1].split(",");
                        int x = Integer.parseInt(cord[0]);
                        int y = Integer.parseInt(cord[1]);
                        char pieza = cord[2].charAt(0);
                        this.actualizarTablero(x,y,pieza,nombreAux,otra);
                    }   
                }
            }
        } catch (IOException ex) {}
    }
    
    public void cargarTxt() throws IOException{
        String linea = recMsg();
        Path ruta = Paths.get("RegistroOso.txt");
        try (BufferedWriter buffer = new BufferedWriter(new FileWriter(ruta.toFile()))) {
            while(!linea.startsWith("FIN_DATOS")){
                System.out.println(linea);
                buffer.write(linea);
                buffer.newLine(); 
                linea = recMsg();
            }
        } catch (IOException e) {}
        System.out.println("Fin datos");
    }
    
    public synchronized int getTurno() {
        return turno;
    }
}

