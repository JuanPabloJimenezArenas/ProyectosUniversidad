/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package oso.ui;
import java.util.Scanner;

/**
 *
 * @author juanp
 */
public class OsoSolitario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.println("Introduzca el numero de filas()");
        String filasStr = "0";
        String columnasStr = "0";
        do{
            filasStr = input.next();
        }while(Integer.parseInt(filasStr)>5 && Integer.parseInt(filasStr)<=0);
        System.out.println("Introduzca el numero de columnas");
        do{
            columnasStr = input.next();
        }while(Integer.parseInt(filasStr)>6 && Integer.parseInt(filasStr)<=0);
        Tablero tablero = new Tablero(Integer.parseInt(filasStr),Integer.parseInt(columnasStr));
        System.out.println(tablero);
        while (!tablero.tableroLleno()){
            System.out.println("Osos:"+tablero.getOsos());
            System.out.println("introduzca jugada:(x,y,letra) ");
            String jugada = input.next();
            String[] datos = jugada.split(",");
            int x = Integer.parseInt(datos[0]);
            int y = Integer.parseInt(datos[1]);
            char letra =(datos[2]).charAt(0);
            if(!tablero.ponerPieza(x, y, letra)){
                System.out.println("Las piezas deben ser S o O, no se pueden alterar las letras de y los valores deben ser [0,"+(Integer.parseInt(filasStr)-1)+"] y [0,"+(Integer.parseInt(columnasStr)-1)+"]");
            }
            else{
                System.out.println(tablero);
            }
            tablero.comprobarOso();
        }
        System.out.println("Puntuacion total: " + tablero.getOsos());
    }
}
