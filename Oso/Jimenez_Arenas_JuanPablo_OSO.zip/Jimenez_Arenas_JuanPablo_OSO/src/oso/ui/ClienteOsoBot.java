/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oso.ui;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author juanp
 */
public class ClienteOsoBot extends Thread{

    private String ip;
    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;
    private Tablero tablero;
    private int turno,puerto;
    private IAOso bot;
    
    
    public ClienteOsoBot(String add, int port) throws IOException {
        this.tablero = new Tablero(5,6,"BOTIA");
        this.bot = new IAOso("BOT",true);
        this.puerto = port;
        this.ip = add;
        socket = new Socket(add, port);
        in = new DataInputStream(
               socket.getInputStream());
        out = new DataOutputStream(
               socket.getOutputStream());
        this.turno = 0;
    }

    public void envioMsg(String msg, boolean otra) throws IOException{
        String mensage = (otra) ? "BOT:"+msg+":"+1 : "BOT:"+msg+":"+0;
        out.writeUTF(mensage);
    }

    public String recMsg() throws IOException{
        return in.readUTF();
    }
    
    private void actualizarTablero(int x, int y, char pieza, String nombre) throws IOException{
        tablero.ponerPieza(x,y,pieza);
        tablero.comprobarOso(nombre);
        if(this.tablero.tableroLleno()){
            boolean win = (this.tablero.getOsosA()>this.tablero.getOsosE());
            String msg = "FIN:"+this.tablero.getOsosA();
            this.envioMsg(msg,win);
        }
    }
    public void desconectar(){
        try {
            socket.close();
        } catch (Exception ex) {}
    }
    
    private void reencolar() throws IOException{
        try {
            socket.close();
        } catch (IOException ex) {}
        socket = new Socket(this.ip, this.puerto);
        in = new DataInputStream(
               socket.getInputStream());
        out = new DataOutputStream(
               socket.getOutputStream());
        this.turno = 0;
        this.tablero.resetear(); 
        String mensaje = "Inicial:BOT";
        try {
            out.writeUTF(mensaje);
        } catch (IOException ex) {}
    }
    
    private void juegaBot(){
        System.out.println(tablero);
        int osoAux = this.tablero.getOsosA();
        /*IAOso.MinimaxResult result = this.bot.calcularMovimientoMinMax(tablero,  -999, 999,"BOTIA" , 5);
        int[] mov = result.mejorMovimiento;*/
        int[] mov = this.bot.movAleatorio(this.tablero);
        int x = mov[0];
        int y = mov[1];
        char p = (mov[2] == 1) ? 'S':'O';
        System.out.println("MovimientoBOT: "+x+","+y);
        tablero.ponerPieza(x, y, p);
        this.tablero.comprobarOso("BOTIA");
        boolean otraVez = this.bot.otraVez(osoAux, this.tablero);
        String msg = ""+x+","+y+","+p;
        try {
            Thread.sleep(5); //esto esta para que le de tiempo al GUI del usuario a refrescarse.
        } catch (InterruptedException ex) {}
        try {
            
            this.envioMsg(msg,otraVez);
        } catch (IOException ex) {}
        System.out.println(tablero);
        if(otraVez && !this.tablero.tableroLleno()){
            this.juegaBot();
        }else if(this.tablero.tableroLleno()){
            boolean win = (this.tablero.getOsosA()>this.tablero.getOsosE());
            msg = "FIN:"+this.tablero.getOsosA();
            try {
                this.envioMsg(msg,win);
            } catch (IOException ex) {}
        }
    }
    
    public void saltarTxt() throws IOException{
        String linea = recMsg();
        while(!linea.startsWith("FIN_DATOS")){
                System.out.println(linea);
                linea = recMsg();
        }
        System.out.println("Fin datos");
    }
    
    @Override
    public void run() {
        try {
            String mensage = "Inicial:BOT";
            out.writeUTF(mensage);
            for(String linea; (linea = recMsg())!=null;){
                System.out.println("Mensaje:"+linea);
                if(linea.equals("INCIO_DATOS")){
                    saltarTxt();
                }else if(linea.startsWith("Turno:")){
                    String[] datos = linea.split(":");
                    this.turno = Integer.parseInt(datos[1]);
                    if(this.turno == 1){
                        this.juegaBot();
                    }
                }else if(linea.endsWith("EXIT")){
                    this.reencolar();
                }else{
                    String[] datos = linea.split(":");
                    String nombreAux = datos[0];
                    if(datos[1].equals("RESET")){
                        this.tablero.resetear();
                    }else{
                        boolean otra = datos[2].equals("1");
                        String[] cord = datos[1].split(",");
                        int x = Integer.parseInt(cord[0]);
                        int y = Integer.parseInt(cord[1]);
                        char pieza = cord[2].charAt(0);
                        this.actualizarTablero(x,y,pieza,nombreAux);
                        if(!otra && !this.tablero.tableroLleno()){    
                            this.juegaBot();
                        }
                    }    
                }
            }
        } catch (IOException ex) {}
    }
    public static void main(String[] args) throws IOException {
        ClienteOsoBot bot = new ClienteOsoBot("127.0.0.1", 4001);
        bot.start();
    }
}

