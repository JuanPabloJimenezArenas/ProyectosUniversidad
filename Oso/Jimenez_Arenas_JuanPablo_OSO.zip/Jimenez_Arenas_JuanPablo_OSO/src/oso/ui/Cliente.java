/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oso.ui;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;

/**
 *
 * @author juanp
 */
public class Cliente extends Thread{

    private String nombre;
    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;
    private JTextArea textArea;

    public Cliente(String nombre, String add, int port, JTextArea textArea) throws IOException {
        this.textArea = textArea;
        this.nombre = nombre;
        socket = new Socket(add, port);
        in = new DataInputStream(
               socket.getInputStream());
        out = new DataOutputStream(
               socket.getOutputStream());
    }

    public void envioMsg(String msg) throws IOException{
        System.out.println("Se envia: "+msg);
        String mensaje = this.nombre+" > "+msg+"\n";
        out.writeUTF(mensaje);
    }

    public String recMsg() throws IOException{
        return in.readUTF();
    }

    @Override
    public void run() {
        String mensaje = "Se ha conectado: "+this.nombre+"\n";
        try {
            out.writeUTF(mensaje);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            for(String linea; (linea = recMsg())!=null;){
                textArea.append(linea);
            }
        } catch (IOException ex) {
        }
    }
    
    public void desconectar(){
        try {
            socket.close();
        } catch (Exception ex) {}
    }
     
}

