package oso.ui;

import java.awt.Color;
import javax.swing.JButton;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author juanp
 */
public class JButtonOso extends JButton{
    int x;
    int y;
    Tablero tablero;

    public JButtonOso(int x, int y, Tablero tablero) {
        this.x = x;
        this.y = y;
        this.tablero = tablero;
    }
    
    public void darValor(){
        switch (this.getText()){
            case " ":
                this.setText("S");
                break;
            case "S":
                this.setText("O");
                break;
            case "O":
                this.setText(" ");
                break;
            default:
                this.setText(" ");
                break;
        }
    }   

    public void actualizarTablero() {
        if("O".equals(this.getText()) || "S".equals(this.getText())){
            char pieza = this.getText().charAt(0);
            this.tablero.ponerPieza(this.x,this.y,pieza);
        }
    }

    public boolean botonSelecionado() {
        return !(' '==(this.tablero.getPieza(this.x,this.y)));
    }

    public void actualizarBoton() {
        switch (this.tablero.getIntAux(this.x,this.y)) {
            case 1:
                this.setText(""+this.tablero.getPieza(x, y));
                this.setForeground(Color.blue);
                break;
            case 2:
                this.setText(""+this.tablero.getPieza(x, y));
                this.setForeground(Color.red);
                break;
            case 3:
                this.setText(""+this.tablero.getPieza(x, y));
                this.setForeground(Color.black);
                break;
            case 0:
                this.setText(""+this.tablero.getPieza(x, y));
                this.setForeground(Color.black);
                break;
            default:
                break;
        }
    }
    
    public String getBoton(){
        return ""+this.x+","+this.y+","+this.getText();
    }

    void reactivarBoton() {
        switch (this.tablero.getIntAux(this.x,this.y)) {
            case 1:
                this.setEnabled(false);
                break;
            case 2:
                this.setEnabled(false);
                break;
            case 3:
                this.setEnabled(false);
                break;
            case 0:
                this.setEnabled(true);
                break;
            default:
                break;
        }
    }
}
