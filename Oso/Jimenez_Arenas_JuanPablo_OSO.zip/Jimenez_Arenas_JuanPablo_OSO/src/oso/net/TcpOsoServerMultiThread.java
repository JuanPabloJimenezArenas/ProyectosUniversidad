package oso.net;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class TcpOsoServerMultiThread extends Thread {
    int puerto;
    ServerSocket serverSocket;
    List<Socket> clientesPendientes;

    public TcpOsoServerMultiThread(int puerto) throws IOException {
        this.puerto = puerto;
        this.serverSocket = new ServerSocket(puerto);
        this.clientesPendientes = new CopyOnWriteArrayList<>();
    }

    @Override
    public void run() {
        System.out.println("Servidor iniciado en el puerto "+this.puerto);
        Map<String,Integer> mapa = new HashMap<>();
        Path ruta = Paths.get("Ganadores.ser");
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta.toFile()))) {
            mapa = (HashMap<String, Integer>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {}
        for(String nombre : mapa.keySet()){
            int puntos = mapa.get(nombre);
            String msg = nombre+": "+puntos;
            System.out.println(msg);
        }
        while (true) {
            try {
                Socket clientSocket = serverSocket.accept();
                clientesPendientes.add(clientSocket);
                System.out.println("alguien entro en cola");
                for(Socket aux:clientesPendientes){
                    if(aux.isClosed()){
                        clientesPendientes.remove(aux);
                    }
                }
                if (clientesPendientes.size() >= 2) {
 
                    Socket s1 = clientesPendientes.remove(0);
                    Socket s2 = clientesPendientes.remove(0);
                    TcpOsoConexionMultiThread[] partida = new TcpOsoConexionMultiThread[2];
                    TcpOsoConexionMultiThread c1 = new TcpOsoConexionMultiThread(s1, partida,0,mapa);
                    partida[0] = c1;
                    c1.start();
                    TcpOsoConexionMultiThread c2 = new TcpOsoConexionMultiThread(s2, partida,1,mapa);
                    partida[1] = c2;
                    c2.start();
                    
                }
            } catch (IOException ex) {
                System.err.println("Error aceptando cliente: " + ex.getMessage());
            }
        }
    }

    public static void main(String[] args) throws IOException {
        TcpOsoServerMultiThread server = new TcpOsoServerMultiThread(4001);
        server.start();
    }
}