/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package oso.net;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import oso.ui.Tablero;

/**
 *
 * @author juanp
 */
public class TcpOsoConexionMultiThread extends Thread{
    
    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;
    private TcpOsoConexionMultiThread[] clientes;
    private String nombre;
    private Map<String,Integer> finOso;
    private boolean cambiado;
    private int index;
    

    public TcpOsoConexionMultiThread(Socket clientSocket, TcpOsoConexionMultiThread[] clientes, int index, Map<String,Integer> map) throws IOException {
        this.socket = clientSocket;
        this.index = index;
        this.finOso = map;
        this.cambiado = false;
        in = new DataInputStream(
                socket.getInputStream());
        out = new DataOutputStream(
                socket.getOutputStream());
        System.out.println("Socket connected to "
                + socket.getInetAddress() + ":"
                + socket.getPort());
        this.clientes = clientes;
    }
    
    private void desconectarSocket(){
        clientes[index] = null;
        System.out.println("Se desconecto "+this.nombre);
        try {
            socket.close();
        } catch (IOException ex) {}
        try{    
            this.clientes[1-this.index].envioMsg("server:EXIT");
        }catch(NullPointerException ex){}
    }
    
    public void envioMsg(String msg){
        try {
            out.writeUTF(msg);
        } catch (IOException ex) {}
    }
    
    public String recMsg(){
        try {
            String msg =in.readUTF();
            return msg;
        } catch (SocketException ex) {
            this.desconectarSocket();
        } catch (IOException ex) {}
        return null;
    }

    @Override
    public synchronized void run() {
        mandarGanadores();
        this.envioMsg("server:RESET");
        for(String linea; (linea = recMsg())!=null;){
            if(linea.startsWith("Inicial:")){
                String[] datos = linea.split(":");
                this.nombre = datos[1]+index;
                int turno = (this.clientes[0] == this) ? 1 : 2;
                String msg = "Turno:"+turno+":"+this.nombre;
                this.envioMsg(msg);
            }else{
                String[] datos = linea.split(":");
                if(datos[1].equals("FIN")){
                    System.out.println("Fin");
                    String nombre = this.nombre.substring(0,this.nombre.length()-1);
                    String victoria = datos[3];
                    ponerJugador(victoria,nombre);
                    this.envioMsg("server:EXIT");
                    mandarGanadores();
                }else{
                    this.clientes[1-this.index].envioMsg(linea);
                }
            }
            System.out.println("Mensaje: "+linea);
        }
        this.desconectarSocket();
    }
    public String getNombre() {
        return nombre;
    }

    private synchronized void ponerJugador(String victoria,String nombre){
        int puntos = 1;
        if(victoria.equals("1")){
            System.out.println("ganador: "+nombre);
            if(this.finOso.containsKey(nombre)){
                puntos+=(int)this.finOso.get(nombre);
                this.finOso.put(nombre, puntos);
            }else{
                this.finOso.put(nombre, puntos);
            }
            Path ruta = Paths.get("Ganadores.ser");
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta.toFile()))) {
                oos.writeObject(this.finOso);
            } catch (IOException e) {}
        }
    }
    private void mandarGanadores(){
        this.envioMsg("INCIO_DATOS");
        for(String nombre : finOso.keySet()){
            int puntos = finOso.get(nombre);
            String msg = nombre+": "+puntos;
            this.envioMsg(msg);
        }
        this.envioMsg("FIN_DATOS");
    }
}
