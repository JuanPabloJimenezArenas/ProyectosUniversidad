/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package oso.net;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author juanp
 */
public class TcpChatConexionMultiThread extends Thread{
    
    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;
    private List<TcpChatConexionMultiThread> clientes;

    public TcpChatConexionMultiThread(Socket clientSocket, List<TcpChatConexionMultiThread> clientes) throws IOException {
        this.socket = clientSocket;
        in = new DataInputStream(
                socket.getInputStream());
        out = new DataOutputStream(
                socket.getOutputStream());
        System.out.println("Socket connected to "
                + socket.getInetAddress() + ":"
                + socket.getPort());
        this.clientes = clientes;
    }
    
    public void envioMsg(String msg){
        try {
            out.writeUTF(msg);
        } catch (IOException ex) {
            Logger.getLogger(TcpChatConexionMultiThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public String recMsg(){
        try {
            String msg = in.readUTF();
            return msg;
        }catch(SocketException | EOFException ex) {
            clientes.remove(this);
            try {
                socket.close();
            } catch (IOException ex1) {}
        }catch (IOException ex) {
            Logger.getLogger(TcpChatConexionMultiThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public void run() {
            for(String line; (line = recMsg())!=null;){
                System.out.println(line);
                for(TcpChatConexionMultiThread c : clientes){
                    c.envioMsg(line);
                }
            }
        clientes.remove(this);
        try {
            socket.close();
        } catch (IOException ex) {}
    }
}
