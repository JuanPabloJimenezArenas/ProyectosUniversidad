/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oso.net;

import oso.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author juanp
 */
public class TcpChatServerMultiThread {
    
    public static void main(String[] args) throws IOException{
        int port = 4000;
        ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("Started server oon "+port);
        List<TcpChatConexionMultiThread> clientes = new CopyOnWriteArrayList<TcpChatConexionMultiThread>();

        while(true){
            try{
                Socket clientSocket = serverSocket.accept();
                TcpChatConexionMultiThread aux = new TcpChatConexionMultiThread(clientSocket,clientes);
                aux.start();
                clientes.add(aux);
            }catch(SocketException se){
                System.out.println("Connection lost: "+ se.getMessage());
            }
        }
    }
}
